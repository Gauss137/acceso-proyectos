"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { UserIcon, ListIcon, ArrowRightIcon } from "lucide-react"

export default function ProjectAccessForm() {
  const [userId, setUserId] = useState("")
  const [projectNumber, setProjectNumber] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call or redirection
    setTimeout(() => {
      // In a real application, this would redirect to the Google Drive link
      // associated with the project number
      alert(`Redirigiendo a los archivos del Proyecto #${projectNumber}`)
      setIsLoading(false)
    }, 1000)
  }

  return (
    <Card className="shadow-lg">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold text-center">Acceda a sus Archivos de Proyecto</CardTitle>
        <CardDescription className="text-center">
          Ingrese sus credenciales para acceder a los archivos del proyecto
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="userId">ID de Usuario</Label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                <UserIcon className="h-5 w-5" />
              </div>
              <Input
                id="userId"
                type="text"
                placeholder="Ingrese su ID de Usuario"
                className="pl-10"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="projectNumber">Número de Proyecto</Label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                <ListIcon className="h-5 w-5" />
              </div>
              <Input
                id="projectNumber"
                type="text"
                placeholder="Ingrese el Número de Proyecto"
                className="pl-10"
                value={projectNumber}
                onChange={(e) => setProjectNumber(e.target.value)}
                required
              />
            </div>
          </div>

          <p className="text-sm text-muted-foreground">
            Puede encontrar su número de proyecto en la documentación proporcionada.
          </p>
        </form>
      </CardContent>
      <CardFooter>
        <Button className="w-full" onClick={handleSubmit} disabled={isLoading}>
          {isLoading ? (
            <span className="flex items-center">
              <svg
                className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Procesando...
            </span>
          ) : (
            <span className="flex items-center justify-center">
              Acceder al Proyecto
              <ArrowRightIcon className="ml-2 h-4 w-4" />
            </span>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

